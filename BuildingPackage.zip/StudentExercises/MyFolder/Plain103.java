public class Plain103 {
    public static void main(String[] args) {
        Student s = new Student(2020999103,"Java");
        System.out.println("Student ID: " + s.id 
                         + "\nStudent Name: " + s.name);
    }
}

