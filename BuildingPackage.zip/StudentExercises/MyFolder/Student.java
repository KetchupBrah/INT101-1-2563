class Student {
    long id;
    String name;

    Student(long id, String name) {
        this.id = id;
        this.name = name;
    }
}
